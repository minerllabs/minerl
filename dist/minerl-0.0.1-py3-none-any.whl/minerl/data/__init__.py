def init():
    pass


def reset():
    pass


def filter(fn):
    pass


def sample():
    return 'the best data'
    pass


def batch():
    pass