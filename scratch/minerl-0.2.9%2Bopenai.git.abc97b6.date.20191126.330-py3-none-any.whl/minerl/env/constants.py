# TODO get the full list from java someplace.
ALL_ITEMS = [
        'none', # empty inventory slot
        'invalid', # item not in the list
        'dirt',
        'coal',
        'torch',
        'log',
        'planks',
        'stick',
        'crafting_table',
        'wooden_axe',
        'wooden_pickaxe',
        'stone',
        'cobblestone',
        'furnace',
        'stone_axe',
        'stone_pickaxe',
        'iron_ore',
        'iron_ingot',
        'iron_axe',
        'iron_pickaxe',
    ]

class Buttons():
    ATTACK = "attack"
    BACK = "back"
    FORWARD = "forward"
    JUMP = "jump"
    LEFT = "left"
    RIGHT = "right"
    SNEAK = "sneak"
    SPRINT = "sprint"

    ALL = [ATTACK, BACK, FORWARD, JUMP, LEFT, RIGHT, SNEAK, SPRINT]