import numpy as np

from minerl.env import spaces
from minerl.env.constants import ALL_ITEMS, Buttons

unified_observation_space = spaces.Dict({
    'pov': spaces.Box(low=0, high=255, shape=(64, 64, 3), dtype=np.uint8),
    # TODO(dfarhi) add these:
    # 'inventory': spaces.Dict({item: spaces.Box(low=0, high=2304, shape=(), dtype=np.int) for item in ALL_ITEMS}),
    # 'equipped_items': spaces.Dict({
    #     'mainhand': spaces.Dict({
    #         'type': spaces.Enum(*ALL_ITEMS),
    #         'damage': spaces.Box(low=-1, high=1562, shape=(), dtype=np.int),
    #         'maxDamage': spaces.Box(low=-1, high=1562, shape=(), dtype=np.int),
    #     })
    # })
})

binary_actions = {b: spaces.Discrete(2) for b in Buttons.ALL}
all_actions = {
    "camera": spaces.Box(low=-180, high=180, shape=(2,), dtype=np.float32),  # Pitch, Yaw
    "place": spaces.Enum(*ALL_ITEMS),
    "equip": spaces.Enum(*ALL_ITEMS),
    "craft": spaces.Enum(*ALL_ITEMS),
     }
all_actions.update(binary_actions)

unified_action_space = spaces.Dict(all_actions)